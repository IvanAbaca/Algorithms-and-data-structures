#ifndef INDICESOCIOAUX_H_INCLUDED
#define INDICESOCIOAUX_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "..\Librerias\Indice\LibIndice.h"
#include "..\Librerias\t_Socios\Libt_Socios.h"

void mostrarIndice(const void* clave, unsigned nro_reg, void* param);
int cmpNroSocios(const void* n1, const void* n2);
int cargarArchivo(const char* arch);
int TxtABin(const char* archTxt, const char* archBin);
void trozarTxtABin(char* linea, char corte, void* auxStruct);
int grabarIndiceDesdeArchivo(t_indice* ind, const char* path);

#endif // INDICESOCIOAUX_H_INCLUDED
