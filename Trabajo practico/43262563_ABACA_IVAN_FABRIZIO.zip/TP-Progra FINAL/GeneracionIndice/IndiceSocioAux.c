#include "IndiceSocioAux.h"

void mostrarIndice(const void* clave, unsigned nro_reg, void* param) // *((unsigned*)((ind->lista->info)+4))
{
    printf("NroSocio: %d\t NroReg: %d\n", *(int*)clave, *((unsigned*)((clave)+4)));
}

int cmpNroSocios(const void* n1, const void* n2)
{
    return *(int*)n1 - *(int*)n2;
}

int cargarArchivo(const char* arch)
{
    int i;
    t_socio socios[] =  {
                        {20,"Midi, Keira",41237657,{01,02,2000},'F',{02,10,2023},"ADULTO",{02,11,2023},'A',{0,0,0}},
                        {01,"Gonzales, Tomas",40297752,{01,02,1999},'M',{10,05,2023},"CADETE",{01,11,2023},'A',{0,0,0}},
                        {15,"Aran, Diana",48237657,{17,11,2010},'F',{01,01,2023},"MENOR",{01,06,2023},'I',{01,07,2023}},
                        {21,"Doss, Tres",41237657,{01,02,2000},'O',{02,10,2023},"ADULTO",{02,11,2023},'A',{0,0,0}},
                        {02,"Cor, Ligeia ",40297752,{01,02,1999},'M',{10,05,2023},"HONORARIO",{01,11,2023},'A',{0,0,0}},
                        {16,"Pepin, Pepon",35237657,{17,11,1967},'M',{01,01,2023},"JUBILADO",{01,06,2023},'I',{01,07,2023}}
                        };

    FILE* pf = fopen(arch, "wt");
    //FILE* pf = fopen(arch, "wb");

    if(!pf)
        return 0;

    for(i = 0; i<(sizeof(socios)/sizeof(t_socio)); i++)
        fprintf(pf, "%ld|%s|%ld|%d/%d/%d|%c|%d/%d/%d|%s|%d/%d/%d|%c|%d/%d/%d\n", socios[i].nroSocio,
                                                                                 socios[i].nyap,
                                                                                 socios[i].dni,
                                                                                 socios[i].fechaNac.dd, socios[i].fechaNac.mm, socios[i].fechaNac.aaaa,
                                                                                 socios[i].sexo,
                                                                                 socios[i].fAfiliacion.dd, socios[i].fAfiliacion.mm, socios[i].fAfiliacion.aaaa,
                                                                                 socios[i].categoria,
                                                                                 socios[i].fUltCuota.dd, socios[i].fUltCuota.mm, socios[i].fUltCuota.aaaa,
                                                                                 socios[i].estado,
                                                                                 socios[i].fBaja.dd, socios[i].fBaja.mm, socios[i].fBaja.aaaa);


    //fwrite(&socios, sizeof(t_socio), sizeof(socios)/sizeof(t_socio), pf);

    fclose(pf);

    return 1;
}

int TxtABin(const char* archTxt, const char* archBin)
{
    t_socio auxSocio;
    char linea[200];

    FILE* pf = fopen(archTxt, "rt");
    FILE* auxpf = fopen(archBin, "wb");

    if(!pf || !auxpf)
        return 0;

    while(fgets(linea, sizeof(linea), pf))
    {
        trozarTxtABin(linea, '|', &auxSocio);
        fwrite(&auxSocio, sizeof(t_socio), 1, auxpf);
    }

    fclose(pf);
    fclose(auxpf);

    return 1;
}

void trozarTxtABin(char* linea, char corte, void* auxStruct)
{
    t_socio* auxSocio = (t_socio*)auxStruct;
    char* pl = strchr(linea, '\n');
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%d/%d/%d", &(auxSocio->fBaja.dd), &(auxSocio->fBaja.mm), &(auxSocio->fBaja.aaaa));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%c", &(auxSocio->estado));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%d/%d/%d", &(auxSocio->fUltCuota.dd), &(auxSocio->fUltCuota.mm), &(auxSocio->fUltCuota.aaaa));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%s", (auxSocio->categoria));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%d/%d/%d", &(auxSocio->fAfiliacion.dd), &(auxSocio->fAfiliacion.mm), &(auxSocio->fAfiliacion.aaaa));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%c", &(auxSocio->sexo));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%d/%d/%d", &(auxSocio->fechaNac.dd), &(auxSocio->fechaNac.mm), &(auxSocio->fechaNac.aaaa));
    *pl = '\0';

    pl = strrchr(linea, corte);
    sscanf(pl+1, "%ld", &(auxSocio->dni));
    *pl = '\0';

    pl = strrchr(linea, corte);
    //sscanf(pl+1, "%s", (auxSocio->nyap));
    strcpy(auxSocio->nyap, pl+1);
    *pl = '\0';

    sscanf(linea, "%ld", &(auxSocio->nroSocio));

}

int grabarIndiceDesdeArchivo(t_indice* ind, const char* path) // Grabo mi indice desde un inicio con el archivo binario solicitado, en este caso el de socios.
{
    t_socio auxSocio;
    unsigned cont = 0;
    FILE* pf = fopen(path, "rb");

    if(!pf)
        return 0;

    fread(&auxSocio, sizeof(t_socio), 1, pf);

    while(!feof(pf)) // Mientras tenga archivo, voy a ir cargando el indice ordenadamente.
    {
        if(auxSocio.estado == 'A') // Cargo solo los que tengan estado activo, los que estan de baja deberian de estar eliminados, por lo tanto no existen en mi indice.
            ind_insertar(ind, &(auxSocio.nroSocio), cont); // Inserto ordenadamente en mi indice.

        fread(&auxSocio, sizeof(t_socio), 1, pf);
        cont++;
    }

    fclose(pf);
    return 1;
}


