#include "IndiceSocioAux.h"

#define archTxt "../Archivos/Socios.txt"
#define archBin "../Archivos/Socios.dat"
#define archInd "../Archivos/Socios.idx"

int main()
{
    char pathTxt[TAM_MAX];
    t_indice ind;

    cargarArchivo(archTxt);

    printf("///////////////////GENERACION DE INDICES SOCIOS//////////////////\n");
    printf("Ingrese el path del archivo txt: ");
    fflush(stdin);
    gets(pathTxt);

    printf("\nGenerando archivo binario...");
    if(TxtABin(pathTxt,archBin))
    {
        printf("\nGenerando indice...");
        ind_crear(&ind, sizeof(long), cmpNroSocios);
        grabarIndiceDesdeArchivo(&ind,archBin);
        ind_grabar(&ind, archInd);

        printf("\n>>>Indice generado exitosamente.\n");
        ind_recorrer(&ind, mostrarIndice, NULL);
        ind_vaciar(&ind);
    }
    else
        printf("No se pudo generar el indice");

    return 0;
}
