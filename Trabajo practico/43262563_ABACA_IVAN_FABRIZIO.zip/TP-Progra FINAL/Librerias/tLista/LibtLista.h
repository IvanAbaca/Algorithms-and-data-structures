#ifndef LIBTLISTA_H_INCLUDED
#define LIBTLISTA_H_INCLUDED

#include <stdio.h>

#define min(x,y) ((x)<(y))? (x) : (y)

typedef struct s_nodo
{
    void* info;
    size_t tam;
    struct s_nodo* sig;

} t_nodo;

typedef t_nodo* t_lista;

void crear_lista(t_lista* pl);
int insertar_ordenado(t_lista* pl, const void* info, size_t tam, int(*cmp)(const void*, const void*));
int sacar_elem_de_lista(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*));
int sacar_del_inicio(t_lista* pl, void* info, size_t tam);
int buscar_elem_lista(const t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*));
int lista_llena(const t_lista* pl, size_t tam);
int lista_vacia(const t_lista* pl);
void vaciar_lista(t_lista* pl);
int recorrer_lista(const t_lista* pl, void(*accion)(const void*, unsigned, void*), void* param);
int cargarListaDesdeArchivo(t_lista* pl, void* info, size_t tam, FILE* pf);
int cargarArchivoDesdeLista(const t_lista* pl, void* info, size_t tam, FILE* pf);
int insertar_n_elementos(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*), int* n);
int listaPrimero(t_lista* pl, void* info, size_t tam);
int listaSiguienteDelIndice(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*));
int esFinDeLista(const t_lista* pl, void* clave,int(*cmp)(const void*, const void*));
int sacar_del_final(t_lista* pl, void* info, size_t tam);



#endif // LIBTLISTA_H_INCLUDED
