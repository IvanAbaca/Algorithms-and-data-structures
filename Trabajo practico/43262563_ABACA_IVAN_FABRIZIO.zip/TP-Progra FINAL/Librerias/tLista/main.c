#include "LibtLista.h"
#include <stdlib.h>
#include <string.h>

void crear_lista(t_lista* pl)
{
    *pl = NULL;
}

int insertar_ordenado(t_lista* pl, const void* info, size_t tam, int(* cmp)(const void*, const void*))
{
    t_nodo* nue = malloc(sizeof(t_nodo));
    int comp;

    if(!nue)
        return 0;

    nue->info = malloc(tam);

    if(!nue->info)
    {
        free(nue);
        return 0;
    }

    while(*pl && (comp = cmp(info, (*pl)->info)) > 0) // Me guardo la comparacion en comp.
        pl = &(*pl)->sig;

    if(!comp) // Si comp da 0, quiere decir que tengo un duplicado, x lo tanto salgo.
        return 0;

    // Si no sali x duplicado voy a insertar en el final, o en el lugar indicado.

    memcpy(nue->info, info, tam);
    nue->tam = tam;

    nue->sig = *pl;

    *pl = nue;

    return 1;
}

int sacar_del_inicio(t_lista* pl, void* info, size_t tam) // Esencialmente, lo mismo que sacar de pila.
{
    t_nodo* elim = *pl;

    if(!*pl)
        return 0;

    memcpy(info, elim->info, min(elim->tam, tam));

    *pl = elim->sig;

    free(elim->info);
    free(elim);

    return 1;
}

int sacar_elem_de_lista(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*)) // Tengo que buscar el elemento.
{
    int comp;
    t_nodo* elim;

    if(!*pl)
        return 0;

    while(*pl && (comp = cmp(info, (*pl)->info)) != 0) // Mientras no encuentre el elemento, me sigo moviendo.
        pl = &(*pl)->sig;

    // Si salgo es porque o me quede sin lista, o porque lo encontre.

    if(comp != 0) // Si la comparacion no es 0, quiere decir q me quede sin lista, asiq salgo.
        return 0;

    elim = *pl;

    memcpy(info, elim->info, min(tam, elim->tam));

    *pl = elim->sig;

    free(elim->info);
    free(elim);

    return 1;
}

int buscar_elem_lista(const t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*))
{
    int comp;

    if(!*pl)
        return 0;

    while(*pl && (comp = cmp(info, (*pl)->info)) != 0) // Lo mismo que eliminar, me muevo hasta encontrar el elemento.
        pl = &(*pl)->sig;

    if(comp != 0) // Si no lo encuentro, salgo.
        return 0;

    memcpy(info, (*pl)->info, min(tam, (*pl)->tam));

    return 1;
}


int lista_llena(const t_lista* pl, size_t tam)
{
    t_nodo* nue = malloc(sizeof(t_nodo));

    if(!nue)
        return 1;

    nue->info = malloc(sizeof(tam));

    if(!nue->info)
    {
        free(nue);
        return 1;
    }

    return 0;
}

int lista_vacia(const t_lista* pl)
{
    if(!*pl)
        return 1;

    return 0;
}

void vaciar_lista(t_lista* pl)
{
    t_nodo* elim;

    while(*pl)
    {
        elim = *pl;

        *pl = elim->sig;

        free(elim->info);
        free(elim);
    }
}

int recorrer_lista(const t_lista* pl, void(*accion)(const void*, unsigned, void*), void* param) // En esencia, un map.
{
    if(!*pl) // Si me mandan una lista vacia, salgo.
        return 0;

    while(*pl) // Mientras tenga lista, a cada registro (nodo) de la misma, le hago una accion.
    {
        accion((*pl)->info, (*pl)->tam, param);
        pl = &(*pl)->sig;
    }

    return 1;
}


int cargarListaDesdeArchivo(t_lista* pl, void* info, size_t tam, FILE* pf) // Cargo una lista a partir de un archivo binario.
{
    fread(info, tam, 1, pf); // Como ya tengo el puntero del archivo, me guardo el primer registro en info, con tamanio tam.

    while(!feof(pf)) // Mientras tenga archivo, voy a ir cargando la lista con cada registro del mismo.
    {
        t_nodo* nue = malloc(sizeof(t_nodo));

        if(!nue)
            return 0;

        nue->info = malloc(tam);

        if(!nue->info)
        {
            free(nue);
            return 0;
        }

        memcpy(nue->info, info, tam);
        nue->tam = tam;
        nue->sig = NULL;

        *pl = nue;

        //Lo de abajo ocurre si suponemos que ya viene ordenado, tambien puedo hacerlo des-ordenado igual.

        pl = &(*pl)->sig; // El objetivo de hacer esto con el puntero al archivo, es que una vez que inserto, yo me muevo al registro siguiente, entonces no tengo que recorrer toda la lista de nuevo para insertar un dato.

        // Como me muevo siempre, si mi archivo tiene 5000 registro, no voy a tener que recorrer toda la lista.

        fread(info, tam, 1, pf); // Leo el siguiente registro a insertar.
    }

    return 1;
}

int cargarArchivoDesdeLista(const t_lista* pl, void* info, size_t tam, FILE* pf) // Inversa de cargar una lista desde archivo, cargo un archivo con el contenido de una lista.
{
    //Recibo el puntero del archivo el cual va a ser escrito (binario).

    if(!*pl)
        return 0;

    while(*pl) // Mientras tenga lista, voy a ir cargando el archivo con cada registro de la misma.
    {
        //memcpy(info, (*pl)->info, tam); // Me copio lo que tengo en la lista en info.

        fwrite((*pl)->info, tam, 1, pf); // Lo grabo en el archivo binario.

        pl = &(*pl)->sig;
    }

    return 1;
}

int insertar_n_elementos(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*), int* n)
{
    t_nodo* nue = malloc(sizeof(t_nodo));
    t_nodo* elim;
    int comp;


    if(!*n)
    {
        if(cmp(info, (*pl)->info) > 0)
            return 0;

        elim = *pl;

        *pl = elim->sig;

        free(elim->info);
        free(elim);

        *n+=1;
    }

    while(*pl && (comp = cmp(info, (*pl)->info)) < 0 && *n >= 0)
        pl = &(*pl)->sig;

    if(!nue)
        return 0;

    nue->info = malloc(tam);

    if(!nue->info)
    {
        free(nue);
        return 0;
    }

    memcpy(nue->info, info, tam);

    nue->tam = tam;

    nue->sig = *pl;

    *pl = nue;

    *n-=1;

    return 1;
}

int listaPrimero(t_lista* pl, void* info, size_t tam)
{
    if(!*pl)
        return 0;

    memcpy(info, (*pl)->info, min((*pl)->tam, tam));

    return 1;
}

int listaSiguienteDelIndice(t_lista* pl, void* info, size_t tam, int(*cmp)(const void*, const void*))
{
    if(!*pl)
        return 0;

    while( *pl && cmp(info,(*pl)->info)!=0) //me paro en donde estaba el aux_reg_ind
        pl=&(*pl)->sig;

    pl=&(*pl)->sig; //voy al siguiente

    memcpy(info, (*pl)->info, min((*pl)->tam, tam));

    return 1;
}

int esFinDeLista(const t_lista* pl, void* clave,int(*cmp)(const void*, const void*))
{
    if(!*pl)
        return -1; //-1 porque estar�a preguntando si es fin de lista a algo que no tiene lista

    while(*pl && cmp(clave,(*pl)->info)!=0) //me paro en donde estaba el aux_reg_ind
        pl=&(*pl)->sig;

    if((*pl)->sig == NULL)
        return 1;

    return 0;
}

int sacar_del_final(t_lista* pl, void* info, size_t tam) // Esencialmente, lo mismo que sacar de pila.
{
    if(!*pl)
        return 0;

    while((*pl)->sig)
        pl = &(*pl)->sig;

    memcpy(info, (*pl)->info, min((*pl)->tam, tam));

    free((*pl)->info);
    free(*pl);
    *pl=NULL;

    return 1;
}

