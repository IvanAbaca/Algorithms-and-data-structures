#ifndef LIBINDICE_H_INCLUDED
#define LIBINDICE_H_INCLUDED

#define TAM_MAX 50

#include "..\tLista\LibtLista.h"

typedef struct
{
    t_lista lista;
    int(*cmp)(const void*, const void*);
    size_t tam_clave;
    void* aux_reg_ind; //clave - nro reg

} t_indice;

void ind_crear(t_indice* ind, size_t tam_clave, int(*cmp)(const void*, const void*));
int ind_insertar(t_indice* ind, void* clave, unsigned nro_reg);
int ind_eliminar(t_indice* ind, void* clave, unsigned* nro_reg);
int ind_buscar(const t_indice* ind, void* clave, unsigned* nro_reg);
int ind_cargar(t_indice*  ind, const char* path);
int ind_grabar(const t_indice* ind, const char* path);
void ind_vaciar(t_indice* ind);
int ind_recorrer(const t_indice* ind, void(*accion)(const void*, unsigned, void*), void* param);
int cmpNroSocios(const void* n1, const void* n2);
void mostrarIndice(const void* clave, unsigned nro_reg, void* param);
int grabarIndiceDesdeArchivo(t_indice* ind, const char* path);
int ind_primero (t_indice* ind, void *clave, unsigned* nro_reg);
int ind_siguiente (t_indice* ind, void *clave, unsigned* nro_reg);
int ind_fin(const t_indice *ind);


#endif // LIBINDICE_H_INCLUDED
