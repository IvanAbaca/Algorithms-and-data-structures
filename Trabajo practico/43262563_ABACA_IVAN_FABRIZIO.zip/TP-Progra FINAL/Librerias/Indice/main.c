#include <string.h>
#include <stdlib.h>
#include "LibIndice.h"

void ind_crear(t_indice* ind, size_t tam_clave, int(*cmp)(const void*, const void*))
{
    crear_lista(&(ind->lista)); // Creo la lista en la cual voy a tener los registro de mi indice.
    ind->cmp = cmpNroSocios; // Me guardo la funcion de comparacion de la clave principal.
    ind->aux_reg_ind = malloc(tam_clave + sizeof(unsigned)); // Reservo memoria para mis registros.
    ind->tam_clave = tam_clave; // Me guardo el tamanio de mi clave.

    if(!ind->aux_reg_ind)
        return;
}

int ind_insertar(t_indice* ind, void* clave, unsigned nro_reg)
{
    memcpy(ind->aux_reg_ind, clave, ind->tam_clave);
    memcpy(ind->aux_reg_ind+ind->tam_clave, &nro_reg, sizeof(unsigned));

    // Cargo la info en aux_reg_ind con los memcpy para luego insertarlos ordenadamente en la lista de mi indice.

    return insertar_ordenado(&(ind->lista), ind->aux_reg_ind, ind->tam_clave+sizeof(unsigned), ind->cmp);
}

int ind_eliminar(t_indice* ind, void* clave, unsigned* nro_reg)
{
    int r;

    memcpy(ind->aux_reg_ind, clave, ind->tam_clave); // Me guardo en aux_reg_ind la clave que tengo que eliminar de mi indice.

    r = sacar_elem_de_lista(&(ind->lista), ind->aux_reg_ind, (ind->tam_clave)+sizeof(unsigned), ind->cmp); // Elimino de mi indice dicho registro con dicha clave y me traigo los datos en aux_reg_ind.

    //Devuelvo los datos del registro eliminado por si se quiere hacer algo con ellos.

    if(r)
    {
        memcpy(clave, ind->aux_reg_ind, ind->tam_clave);
        memcpy(nro_reg, ind->aux_reg_ind+ind->tam_clave, sizeof(unsigned));
    }

    return r;
}

int ind_buscar(const t_indice* ind, void* clave, unsigned* nro_reg)
{
    int r;

    memcpy(ind->aux_reg_ind, clave, sizeof(int));

    r = buscar_elem_lista(&(ind->lista), ind->aux_reg_ind, ind->tam_clave+sizeof(unsigned), ind->cmp); // Me guardo en una variable, si encontro o no el elemento enviado por clave.

    if(r) // Si encontre el elemento, los copio a los parametros recibidos en la funcion.
    {
        memcpy(clave, ind->aux_reg_ind, ind->tam_clave);
        memcpy(nro_reg, ind->aux_reg_ind+ind->tam_clave, sizeof(unsigned));
    }

    //Copio en clave y nro_reg la info de mi nodo el cual coincide con lo que yo buscaba.

    return r;
}

int ind_cargar(t_indice* ind, const char* path) // Cargo el indice a partir de un archivo ya ordenado de indices.
{
    FILE* pf = fopen(path, "rb");

    if(!pf)
        return 0;

    cargarListaDesdeArchivo(&(ind->lista), ind->aux_reg_ind, ind->tam_clave+sizeof(unsigned), pf); // Cargo la lista desde mi archivo (de indices ordenados x clave).

    fclose(pf);

    return 1;
}

int ind_grabar(const t_indice* ind, const char* path) // Grabo mi indice en un archivo.
{
    FILE* pf = fopen(path, "wb");

    if(!pf)
        return 0;

    cargarArchivoDesdeLista(&(ind->lista), ind->aux_reg_ind, ind->tam_clave+sizeof(unsigned), pf); // Grabo mi archivo binario con los registros de mi indice (lista).

    fclose(pf);

    return 1;
}

void ind_vaciar(t_indice* ind) // Vacio mi indice, y libero el espacio de memoria reservado que tenia para almacenar la info de mis nodos.
{
    vaciar_lista(&(ind->lista));
    free(ind->aux_reg_ind);
}

int ind_recorrer(const t_indice* ind, void(*accion)(const void*, unsigned, void*), void* param)
{
    return recorrer_lista(&(ind->lista), accion, param); // Recorro mi indice, y aplico una accion a cada registro del mismo (basicamente un map).
}

int ind_primero (t_indice* ind, void *clave, unsigned* nro_reg)
{
    listaPrimero(&(ind->lista),ind->aux_reg_ind,ind->tam_clave+sizeof(unsigned));

    memcpy(clave, ind->aux_reg_ind, ind->tam_clave);
    memcpy(nro_reg, ind->aux_reg_ind+ind->tam_clave, sizeof(unsigned));

    return 1;
}

int ind_siguiente (t_indice* ind, void *clave, unsigned* nro_reg)
{
    listaSiguienteDelIndice(&(ind->lista),ind->aux_reg_ind,ind->tam_clave+sizeof(unsigned),ind->cmp);

    memcpy(clave, ind->aux_reg_ind, ind->tam_clave);
    memcpy(nro_reg, ind->aux_reg_ind+ind->tam_clave, sizeof(unsigned));

    return 1;
}

int ind_fin(const t_indice *ind)
{
    return esFinDeLista(&(ind->lista),ind->aux_reg_ind,ind->cmp);
}




