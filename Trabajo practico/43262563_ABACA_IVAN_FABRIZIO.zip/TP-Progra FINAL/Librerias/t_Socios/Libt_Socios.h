#ifndef LIBT_SOCIOS_H_INCLUDED
#define LIBT_SOCIOS_H_INCLUDED

typedef struct
{
    int dd;
    int mm;
    int aaaa;

}t_fecha;

typedef struct
{
    long nroSocio;
    char nyap[60];
    long dni;
    t_fecha fechaNac;
    char sexo;
    t_fecha fAfiliacion;
    char categoria[10];
    t_fecha fUltCuota;
    char estado;
    t_fecha fBaja;

}t_socio;

#endif // LIBT_SOCIOS_H_INCLUDED
