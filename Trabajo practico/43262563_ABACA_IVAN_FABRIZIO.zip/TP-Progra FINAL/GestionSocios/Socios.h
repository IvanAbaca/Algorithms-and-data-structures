#ifndef SOCIOS_H_INCLUDED
#define SOCIOS_H_INCLUDED

#include <stdio.h>
#include "..\Librerias\t_Socios\Libt_Socios.h"
#include "..\Librerias\Indice\LibIndice.h"

#define MENU_MSJ "Elija una opcion:\n\n" \
                 "A - Dar de alta Socio.\n"\
                 "M - Modificar nombre y apellido de Socio\n"\
                 "B - Dar de baja Socio.\n"\
                 "L - Listar Socios Inactivos.\n"\
                 "V - Visualizar todos los Socios\n"\
                 "P - Listar Socios con retraso en el pago de la cuota\n"\
                 "S - Salir\n"\

#define MENU_OPC "AMBLVPS"

#define MENU_CAT "M - MENOR\n"\
                 "C - CADETE\n"\
                 "A - ADULTO\n"\
                 "V - VITALICIO\n"\
                 "H - HONORARIO\n"\
                 "J - JUBILADO\n"

#define MENUCATOPC "MCAVHJ"

#define TAM_LINEA 150
#define TODO_OK 1
#define ARCH_ERROR -1
#define ERROR_LINEA 0

//Menu
char menu(const char* msj, const char* opc);

int darAlta(t_indice* ind, const char* path);
int modificarSocio(t_indice* ind, const char* path);
int darBaja(t_indice* ind, const char* path);
void listarSociosBajas(const char* path);
void listarSociosAlta(t_indice* ind, const char* path);
void mostrarSociosBaja(t_socio* socio);
void mostrarSociosAlta(void* info, unsigned tam, FILE* pf);
void listarSociosConPagoEnRetraso(t_indice* ind, const char* path);

int cmpFechas(t_fecha f1,t_fecha f2);
int cmpNroSocios(const void* n1, const void* n2);
int cmpSocioPorUltimoPago(const void* socio1, const void* socio2);

int validarCategoria(char* categoria);
int validarNyap(char* nyap);

#endif // SOCIOS_H_INCLUDED
