#include "Socios.h"
#include <string.h>
#include <ctype.h>

int darAlta(t_indice* ind, const char* path)
{
t_socio auxSocio1;
    unsigned nroreg;

    FILE* pf = fopen(path, "r+b");

    if(!pf)
        return 0;

    //Ingresar el numero de socio que queremos dar de alta.
    do
    {
        printf("\nIngrese Numero de Socio: ");
        scanf("%ld", &(auxSocio1.nroSocio));

    } while(auxSocio1.dni < 1 && auxSocio1.dni > 10000000);

    if(!(ind_buscar(ind, &(auxSocio1.nroSocio), &nroreg))) // Si no lo encontre, quiere decir que no es un socio repetido, por lo tanto doy de alta a uno nuevo.
    {
        do
        {
            printf("Ingrese el Apellido y Nombre del nuevo socio (Apellido, Nombre) : ");
            fflush(stdin);
            gets(auxSocio1.nyap);

        } while(!validarNyap(auxSocio1.nyap));

        do
        {
            printf("\nIngrese el DNI del nuevo socio: ");
            scanf("%ld", &(auxSocio1.dni));

        } while(auxSocio1.dni < 10000 && auxSocio1.dni > 100000000);

        printf("Ingrese el fecha de nacimiento del nuevo socio (formato dd/mm/aaaa): ");
        scanf("%d/%d/%d", &(auxSocio1.fechaNac.dd), &(auxSocio1.fechaNac.mm), &(auxSocio1.fechaNac.aaaa));

        do
        {
            printf("\nIngrese el sexo (M (masculino) - F (femenino) u O (otro)): ");
            fflush(stdin);
            scanf("%c", &(auxSocio1.sexo));

        } while(auxSocio1.sexo != 'F' && auxSocio1.sexo != 'M' && auxSocio1.sexo != 'O');

        printf("Ingrese el fecha de afilacion del nuevo socio (formato dd/mm/aaaa)(Fecha del dia de hoy): ");
        scanf("%d/%d/%d", &(auxSocio1.fAfiliacion.dd), &(auxSocio1.fAfiliacion.mm), &(auxSocio1.fAfiliacion.aaaa));
        do
        {
            printf("Ingrese la categoria del nuevo socio (MENOR, CADETE, ADULTO, VITALICIO, HONORARIO, JUBILADO): ");
            fflush(stdin);
            gets(auxSocio1.categoria);

        } while(!validarCategoria(auxSocio1.categoria));

        printf("Ingrese el fecha de ultima cuota paga (formato dd/mm/aaaa)(Fecha del dia de hoy): ");
        scanf("%d/%d/%d", &(auxSocio1.fUltCuota.dd), &(auxSocio1.fUltCuota.mm), &(auxSocio1.fUltCuota.aaaa)); // Poner fecha del dia de hoy.

        auxSocio1.estado = 'A';

        auxSocio1.fBaja.dd = 0, auxSocio1.fBaja.mm = 0, auxSocio1.fBaja.aaaa = 0;

        fseek(pf, 0, SEEK_END);
        fwrite(&auxSocio1, sizeof(t_socio), 1, pf);

        //Una vez que lo escribo en el archivo, tengo que darlo de alta en mi indice ya que es un socio activo nuevo.

        nroreg = (ftell(pf)/sizeof(t_socio))-1;

        ind_insertar(ind, &(auxSocio1.nroSocio), nroreg);
    }

    // Caso contrario, el socio ya existe en el sistema.

    else
        printf("El socio ya existe y se encuentra activo en nuestro sistema.");

    fclose(pf);
    return 1;


}

int modificarSocio(t_indice* ind, const char* path)
{
    t_socio auxSocio;
    unsigned nroreg;
    int clave;

    FILE* pf = fopen(path, "r+b");

    if(!pf)
        return 0;

    printf("Ingrese Numero de Socio: ");
    scanf("%d", &clave);

    if(ind_buscar(ind, &clave, &nroreg)) // Si encuentro el socio, le modifico el nombre.
    {
        //fseek(pf, sizeof(t_socio)*(*((unsigned*)(ind->aux_reg_ind+ind->tam_clave))), SEEK_SET);
        fseek(pf, sizeof(t_socio)*nroreg, SEEK_SET);
        fread(&auxSocio, sizeof(t_socio), 1, pf);

        do
        {
            printf("Ingrese apellido y nombre del socio que va a modificar (Apellido, Nombre): ");
            fflush(stdin);
            gets(auxSocio.nyap);

        } while(!validarNyap(auxSocio.nyap));


        fseek(pf, -(long)sizeof(t_socio), SEEK_CUR);
        fwrite(&auxSocio, sizeof(t_socio), 1, pf);
    }
    else // Caso contrario, no existe el nro de socio.
        printf("Nro de Socio incorrecto.");

    fclose(pf);

    return 1;
}

int darBaja(t_indice* ind, const char* path)
{
    t_socio auxSocio;
    unsigned nroreg;
    int clave;

    FILE* pf = fopen(path, "r+b");

    if(!pf)
        return 0;

    printf("Ingrese Numero de Socio: ");
    scanf("%d", &clave);

    if(ind_eliminar(ind, &clave, &nroreg)) // Elimino directamente de mi indice al socio recibido por parametro para dar de baja.
    {
        // Si encontre al socio a dar de baja, lo modifico en el archivo de socios y lo pongo como inactivo.

        fseek(pf, sizeof(t_socio)*nroreg, SEEK_SET);
        fread(&auxSocio, sizeof(t_socio), 1, pf);

        printf("Ingrese la fecha de baja (Formato dd/mm/aaaa): ");
        scanf("%d/%d/%d", &(auxSocio.fBaja.dd), &(auxSocio.fBaja.mm), &(auxSocio.fBaja.aaaa));
        fflush(stdin);

        auxSocio.estado = 'I';

        fseek(pf, -(long)sizeof(t_socio), SEEK_CUR);
        fwrite(&auxSocio, sizeof(t_socio), 1, pf);

    }

    // Caso contrario:
    else
        printf("El nroSocio no existe en nuestra aplicacion.");


    fclose(pf);

    return 1;
}

void listarSociosBajas(const char* path) // Como mi indice no tiene bajas, tengo que leer el archivo para mostrar a aquellos socios que estan dados de baja.
{
    t_socio socio;

    FILE* pf = fopen(path, "rb");

    if(!pf)
        return;

    fread(&socio, sizeof(t_socio), 1, pf);

    while(!feof(pf))
    {

        if((socio.estado) == 'I')
            mostrarSociosBaja(&socio);

        fread(&socio, sizeof(t_socio), 1, pf);
    }

    fclose(pf);
}

void listarSociosAlta(t_indice* ind, const char* path) // En este caso si puedo utilizar mi indice, ya que en mi indice estan todos los socios activos.
{
    FILE* pf = fopen(path, "rb");

    if(!pf)
        return;

    // Al enviar el puntero al archivo, no necesito recorrer el archivo y puedo traer la estructura directa de dicho registro con un fseek.

    ind_recorrer(ind, (void*)mostrarSociosAlta, pf); // Recorro el indice y por cada uno que leo, lo muestro por pantalla utilizando una funcion y enviando el puntero al archivo.


    fclose(pf);
}

void mostrarSociosBaja(t_socio* socio)
{
    printf("Num Socio: %ld\t Nombre y Apellido: %-15s\t DNI: %ld\t\t Fecha Nacimiento: %d/%d/%d\nSexo: %c\t\t Fecha Afiliacion: %d/%d/%d\t\t Categoria: %s\t Fecha Ultima Cuota Paga: %d/%d/%d\nEstado: %c\t Fecha Baja: %d/%d/%d\n\n\n",
            socio->nroSocio, socio->nyap, socio->dni, socio->fechaNac.dd, socio->fechaNac
            .mm, socio->fechaNac.aaaa, socio->sexo, socio->fAfiliacion.dd, socio->fAfiliacion.mm, socio->fAfiliacion.aaaa,
            socio->categoria, socio->fUltCuota.dd, socio->fUltCuota.mm, socio->fUltCuota.aaaa, socio->estado, socio->fBaja.dd, socio->fBaja.mm, socio->fBaja.aaaa);
}

void mostrarSociosAlta(void* info, unsigned tam, FILE* pf)
{
    t_socio socio;

    fseek(pf, sizeof(t_socio)*(*(unsigned*)(info+sizeof(int))), SEEK_SET);

    fread(&socio, sizeof(t_socio), 1, pf);

    mostrarSociosBaja(&socio);
}

void listarSociosConPagoEnRetraso(t_indice* ind, const char* path)
{
    t_socio socio;
    t_lista lSocio;
    int cantElem=10;
    long clave;
    unsigned nroReg;

    FILE* pf = fopen(path, "rb");

    if(!pf)
        return;

    crear_lista(&lSocio);
    ind_primero(ind, &clave, &nroReg);
    fseek(pf, sizeof(t_socio)*nroReg, SEEK_SET);
    fread(&socio,sizeof(t_socio),1,pf);
    insertar_n_elementos(&lSocio,&socio,sizeof(t_socio),cmpSocioPorUltimoPago,&cantElem);

    while(!ind_fin(ind)) //Cargo socios a lista ordenada (ordenado por fecha de ultimo pago)
    {
        ind_siguiente(ind, &clave, &nroReg);
        fseek(pf, sizeof(t_socio)*nroReg, SEEK_SET);
        fread(&socio,sizeof(t_socio),1,pf);
        insertar_n_elementos(&lSocio,&socio,sizeof(t_socio),cmpSocioPorUltimoPago,&cantElem);
    }

    printf("\nListando los 10 socios con mayor retraso en la fecha de pago de la cuota:\n");
    while(!lista_vacia(&lSocio)) // muestro los primeros 5 socios
    {
        sacar_del_final(&lSocio,&socio,sizeof(t_socio));
        mostrarSociosBaja(&socio);
    }

    vaciar_lista(&lSocio);
    fclose(pf);
}

int cmpNroSocios(const void* n1, const void* n2)
{
    return *(int*)n1 - *(int*)n2;
}

char menu(const char* msj, const char* opc)
{
    char opta;
    int priVez=1;
    do
    {
        if(!priVez)
        {
            priVez=!priVez;
            puts("ERROR - Opcion NO valida.");
        }
        printf(msj);
        fflush(stdin);
        scanf("%c", &opta);
        opta = toupper(opta);
    }while(strchr(opc,opta) == NULL);

    printf("Opcion elegida: %c\n", opta);
    return opta;
}

int validarCategoria(char* categoria)
{
    char vec[][20] = {"MENOR", "CADETE", "ADULTO", "VITALICIO", "HONORARIO", "JUBILADO"};
    int i;
    int comp;

    for(i=0; i<6; i++)
    {
        comp = strcmp(categoria, vec[i]);

        if(!comp)
            return 1;
    }

    return 0;
}

int validarNyap(char* nyap)
{
    int cont = 0;

    if(strlen(nyap) > 60)
        return 0;

    if(!isalpha(*nyap))
        return 0;

    while(*nyap)
    {
        if(!isalpha(*nyap))
        {
            if(*nyap == ',' && *(nyap+1) == ' ' && !cont && isalpha(*(nyap+2)))
            {
                nyap++;
                cont++;
            }
            else if(!cont)
            {
                return 0;
            }
            else
                return 0;
        }

        nyap++;
    }

    return 1;
}

int cmpFechas(t_fecha f1,t_fecha f2) //Fecha 1 mayor que Fecha 2
{
//Comparo los a�os
    if(f1.aaaa > f2.aaaa)
        return 1;
    else if(f1.aaaa < f2.aaaa)
        return -1;
//Si los a�os son iguales, comparo los meses
    if(f1.mm > f2.mm)
        return 1;
    else if(f1.mm < f2.mm)
        return -1;
//si los meses son iguales, comparo los dias
    if(f1.dd > f2.dd)
        return 1;
    else if(f1.dd < f2.dd)
        return -1;

    return 0;
}

int cmpSocioPorUltimoPago(const void* socio1, const void* socio2)
{
    t_socio* s1 = (t_socio*)socio1;
    t_socio* s2 = (t_socio*)socio2;
    return cmpFechas( (s1->fUltCuota) , (s2->fUltCuota) );
}

