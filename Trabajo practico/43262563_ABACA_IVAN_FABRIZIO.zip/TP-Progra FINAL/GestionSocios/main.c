#include <stdio.h>
#include <stdlib.h>
#include "Socios.h"

#define pathIndice "../Archivos/Socios.idx"
#define pathArchBin "../Archivos/Socios.dat"

int main()
{
    char opcion;
    t_indice idx;

    ind_crear(&idx,sizeof(int),cmpNroSocios);
    ind_cargar(&idx,pathIndice);

    opcion= menu(MENU_MSJ,MENU_OPC);

    while(opcion != 'S')
    {
         switch(opcion)
        {
            case 'A':  darAlta(&idx,pathArchBin); break;
            case 'M':  modificarSocio(&idx,pathArchBin); break;
            case 'B':  darBaja(&idx,pathArchBin); break;
            case 'L':  listarSociosBajas(pathArchBin); break;
            case 'V':  listarSociosAlta(&idx,pathArchBin); break;
            case 'P':  listarSociosConPagoEnRetraso(&idx,pathArchBin); break;
            case 'S':  break;
        }

        puts("");
        system("pause");
        system("cls");
        opcion= menu(MENU_MSJ,MENU_OPC);
    }


    ind_grabar(&idx,pathIndice);
    ind_vaciar(&idx);
    return 0;
}
